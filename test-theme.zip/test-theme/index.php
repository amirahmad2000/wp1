<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package test-theme
 */

get_header();
?>

	<main id="primary" class="site-main">

<div class="slider">
    <?php dynamic_sidebar('slider'); ?>
</div>

<div class="part1">
    <div class="part-1">
        <div class="part1-1">
            <?php dynamic_sidebar('part1-1'); ?>
        </div>
    </div>
</div>

<div class="part2">
    <div class="part-2">
        <div class="part2-1">
            <?php dynamic_sidebar('part2-1'); ?>
        </div>
    </div>
</div>

<div class="part3">
    <div class="part-3">
        <div class="part3-1">
            <?php dynamic_sidebar('part3-1'); ?>
        </div>
    </div>

    <div class="part3-2">
        <div class="card1">
            <?php dynamic_sidebar('card1'); ?>
        </div>
        <div class="card2">
            <?php dynamic_sidebar('card2'); ?>
        </div>
        <div class="card3">
            <?php dynamic_sidebar('card3'); ?>
        </div>
        <div class="card4">
            <?php dynamic_sidebar('card4'); ?>
        </div>
    </div>
</div>

<div class="part4">
	<div class="part4-1">
		<?php dynamic_sidebar('part4-1'); ?>
	</div>

	<div class="part4-2">
		<?php dynamic_sidebar('part4-2'); ?>
	</div>
</div>

<div class="part5">
    <div class="container " style="width:50% ; text-align:left;">
        <div class="card-group ccc">
            <div class="card bg-warning col-md-6 ffff" style="width: 200px; height:200px; margin-left: 15px;">
                <div class="card-body text-center eeee">
                    <?php dynamic_sidebar('part5-1'); ?>
                </div>
            </div>
            <div class="card ms-4 bg-primary" style="width:50% ; text-align:left;"> <!-- فاصله از سمت چپ -->
                <div class="card-body text-center eeee">
                    <?php dynamic_sidebar('part5-2'); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="part6">
    <div class="part6-1">
        <?php dynamic_sidebar('part6-1'); ?>
    </div>
    <div class="part6-2">
        <?php dynamic_sidebar('part6-2'); ?>
    </div>
</div>

<div class="part7">
    <div class="part7-1">
        <?php dynamic_sidebar('part7-1'); ?>
    </div>
    <div class="part7-2">
        <?php dynamic_sidebar('part7-2'); ?>
    </div>
    <div class="part7-3">
        <?php dynamic_sidebar('part7-3'); ?>
    </div>
    <div class="part7-4">
        <?php dynamic_sidebar('part7-4'); ?>
    </div>
</div>

<div class="footer1">
    <div class="footer1-1">
        <div class="orange-box">
            <div class="input-group">
                    <input type="text" class="form-control" placeholder="متن خود را وارد کنید">
                    <button class="btn btn-dark" type="button">ارسال</button>
            </div>
        </div>
    </div>
    <div class="footer1-2">

    </div>
    <div class="footer1-3">

    </div>
</div>




	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
